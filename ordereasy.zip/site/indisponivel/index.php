<!DOCTYPE html>
<html lang="pt_BR">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>INDISPONÍVEL - REDIRECIONANDO</title>
    <link href="../novocliente/lib/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="../novocliente/lib/Ionicons/css/ionicons.css" rel="stylesheet">
    <link rel="stylesheet" href="../novocliente/css/slim.css">
  </head>
  <body>
    <div class="signin-wrapper">
      <div class="signin-box signup">
         <center><h2 class="slim-logo"><img src="bg1.png" class="img-fluid" width="200"></h2>
         <h3 class="signin-title-secondary">SISTEMA INDISPONÍVEL</h3></center>
		 <p style="margin-top:10px; color:#FF3333; font-size:13px" align="center"><strong>Tente novamente mais tarde.</strong>
       </div>
    </div>
  </body>
</html>