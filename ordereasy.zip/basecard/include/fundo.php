<div class="slim-footer" style="background-color:<?php print $dadosempresa->corrodape; ?>" align="center">
<div class="container">
<center>Copyright <?php echo date("Y");?> - <?php print $dadosempresa->nomeempresa; ?></center>
</div>
</div>