<?php
define('HOME', 'https://localhost/ordereasy/noahburger/');
setlocale( LC_ALL, 'pt_BR', 'pt_BR.iso-8859-1', 'pt_BR.utf-8', 'portuguese' );
