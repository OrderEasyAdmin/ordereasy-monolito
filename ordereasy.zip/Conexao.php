<?php
$servidor = 'localhost';
$usuario  = 'root';
$senha 	  = '';
$banco    = 'ordereasy';

// FUNCOES DO SISTEMA DE CADASTRO ###########

$nomesite  = 'NOMEDASUAEMPRESA';
$urlmaster = 'localhost/ordereasy'; // APENAS A URL PRINCIPAL SEM A BARRA NO FINAL ---- ----

date_default_timezone_set('America/Sao_Paulo');